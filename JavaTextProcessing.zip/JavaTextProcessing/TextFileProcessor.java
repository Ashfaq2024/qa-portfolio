import java.io.*;
import java.util.*;

public class TextFileProcessor {
    public static void main(String[] args) {
        // Task 1: Reverse the order of lines
        List<String> lines = new ArrayList<>();
        
        // Read the file and store all lines
        try (BufferedReader br = new BufferedReader(new FileReader("input.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line); // Store each line
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Task 1: Reverse the lines and print
        System.out.println("Task 1: Reverse order of lines:");
        Collections.reverse(lines);
        for (String line : lines) {
            System.out.println(line);
        }
        
        // Task 2: Process in chunks of 50 lines at a time and reverse each chunk
        System.out.println("\nTask 2: Process in chunks of 50 lines and reverse:");
        int chunkSize = 50;
        for (int i = 0; i < lines.size(); i += chunkSize) {
            int end = Math.min(i + chunkSize, lines.size());
            List<String> chunk = lines.subList(i, end);
            Collections.reverse(chunk);  // Reverse the current chunk
            for (String line : chunk) {
                System.out.println(line);
            }
        }

        // Task 3: Print a line 42 lines prior when encountering a blank line
        System.out.println("\nTask 3: Print line 42 prior when encountering a blank line:");
        try (BufferedReader br = new BufferedReader(new FileReader("input.txt"))) {
            LinkedList<String> recentLines = new LinkedList<>();
            String line;
            int lineNumber = 0;
            while ((line = br.readLine()) != null) {
                if (lineNumber >= 42 && line.isEmpty()) {
                    System.out.println(recentLines.get(0)); // print the line 42 steps prior
                }
                recentLines.add(line);
                if (recentLines.size() > 43) {
                    recentLines.removeFirst();  // Keep only the last 43 lines
                }
                lineNumber++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Task 4: Remove duplicates and print only unique lines
        System.out.println("\nTask 4: Print only unique lines:");
        Set<String> uniqueLines = new LinkedHashSet<>(lines);  // Using LinkedHashSet to preserve order
        for (String line : uniqueLines) {
            System.out.println(line);
        }

        // Task 5: Print only lines that have already appeared
        System.out.println("\nTask 5: Print only lines that appeared before:");
        Set<String> seenLines = new HashSet<>();
        for (String line : lines) {
            if (seenLines.contains(line)) {
                System.out.println(line);
            } else {
                seenLines.add(line);
            }
        }

        // Task 6: Sort lines by length and print, removing duplicates
        System.out.println("\nTask 6: Sort lines by length and print without duplicates:");
        Set<String> uniqueLinesByLength = new LinkedHashSet<>(lines); // remove duplicates
        List<String> sortedByLength = new ArrayList<>(uniqueLinesByLength);
        sortedByLength.sort(Comparator.comparingInt(String::length).thenComparing(String::compareTo));
        for (String line : sortedByLength) {
            System.out.println(line);
        }

        // Task 7: Sort lines by length, with duplicates included
        System.out.println("\nTask 7: Sort lines by length, including duplicates:");
        List<String> allLinesSorted = new ArrayList<>(lines);
        allLinesSorted.sort(Comparator.comparingInt(String::length).thenComparing(String::compareTo));
        for (String line : allLinesSorted) {
            System.out.println(line);
        }

        // Task 8: Print even-numbered lines first, then odd-numbered lines
        System.out.println("\nTask 8: Print even-numbered lines first, then odd-numbered:");
        List<String> evenLines = new ArrayList<>();
        List<String> oddLines = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            if (i % 2 == 0) {
                evenLines.add(lines.get(i)); // Even-indexed lines
            } else {
                oddLines.add(lines.get(i)); // Odd-indexed lines
            }
        }
        for (String line : evenLines) {
            System.out.println(line);
        }
        for (String line : oddLines) {
            System.out.println(line);
        }

        // Task 9: Randomly shuffle the lines
        System.out.println("\nTask 9: Randomly shuffle the lines:");
        Collections.shuffle(lines);
        for (String line : lines) {
            System.out.println(line);
        }
    }
}
